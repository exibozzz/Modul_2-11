-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 13, 2024 at 01:05 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `baza`
--

-- --------------------------------------------------------

--
-- Table structure for table `proizvodi`
--

CREATE TABLE `proizvodi` (
  `id` int(11) NOT NULL,
  `ime` varchar(128) NOT NULL,
  `opis` text NOT NULL,
  `cena` decimal(10,2) NOT NULL,
  `dan_nabavke` date NOT NULL,
  `kolicina` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `proizvodi`
--

INSERT INTO `proizvodi` (`id`, `ime`, `opis`, `cena`, `dan_nabavke`, `kolicina`) VALUES
(1, 'Deterdžent za posuđe FAIRY lemon 1,2l', 'Osiguravaći miris i čist sjaj, naša tečnost za pranje sudova će transformirati vaše posuđe u blistavu čistotu. Sa snažnim formulama koje se bore protiv masnoće i naslaga hrane, svaka kap ovog čistača donosi svježinu i sjaj u vašu kuhinju. Ne samo da uklanja prljavštinu, već i nježno tretira vaše posuđe, čineći ih sjajnima i bez tragova. Pruža snažno čišćenje bez napora, čineći svakodnevne zadatke lakšim i bržim. Svojom efikasnošću i svežim mirisom, naša tečnost za sudove postaje vaš neizostavan saveznik u održavanju čistog i blistavog doma.', 399.99, '2024-12-05', 3555),
(2, 'Kikiriki puter GRANUM 170g', '\r\nKikiriki puter je ukusan namaz napravljen od samo jednog sastojka - kikirikija! Pripremljen od pažljivo odabranih kikiriki zrna, ovaj puter je punog, bogatog ukusa koji će zadovoljiti vaše nepce. Bez dodatka šećera ili veštačkih aditiva, kikiriki puter je prirodan izvor proteina, zdravih masti i vlakana. Možete ga koristiti kao namaz na hlebu, dodatak smoothiejima ili kao sastojak u raznim receptima. Bogat hranljivim materijama, kikiriki puter je savršen izbor za one koji traže zdravu i ukusnu alternativu u ishrani.', 299.99, '2024-02-02', 244),
(3, 'Hummus RIBELLA karamelizovani luk 200g', '\r\nHummus RIBELLA s karamelizovanim lukom je savršen spoj tradicionalnog ukusa humusa s jedinstvenim dodatkom karamelizovanog luka. Ovaj namaz od čička je neodoljivo kremast, sa blagom notom slatkoće koju donosi karamelizovani\r\n\r\nluk, što dodatno obogaćuje vaše jelovnike. Napravljen od pažljivo odabranih sastojaka, uključujući sveže skuvane čičke, maslinovo ulje i začine, ovaj hummus je bogat izvor proteina i vlakana. Bez dodatka veštačkih boja, konzervansa ili aroma, Hummus RIBELLA s karamelizovanim lukom je ukusan i zdrav izbor za vaše užine, sendviče ili kao prilog uz raznovrsne obroke. Otkrijte jedinstveni spoj tradicije i savremene kulinarske kreativnosti sa svakim zalogajem.', 219.99, '2024-04-05', 750),
(4, 'Dugotrajno mleko IMLEK 2,8%mm 1l', '\r\nDugotrajno mleko IMLEK s 2,8% mlečne masti je kvalitetan proizvod koji će zadovoljiti vaše potrebe za svežim mlekom, ali s dodatnim benefitom dugotrajnog skladištenja. Zahvaljujući posebnom procesu pasterizacije i pakovanju, IMLEK dugotrajno mleko zadržava svežinu i hranljive vrednosti duže od standardnog svežeg mleka, čime omogućava praktičniju upotrebu i skladištenje.\r\n\r\nOvo mleko sadrži 2,8% mlečne masti, pružajući bogat, kremast ukus koji će zadovoljiti vaše čulo ukusa. Sadrži esencijalne hranljive sastojke poput proteina, kalcijuma i vitamina D, čineći ga važnim dodatkom zdravoj ishrani.\r\n\r\nSvojom praktičnošću, dugim rokom trajanja i visokim standardima kvaliteta, IMLEK dugotrajno mleko je idealan izbor za porodice, pojedince ili svakoga ko želi uživati u svežem mleku bez brige o brzom isteku roka trajanja. Uživajte u njegovom bogatom ukusu i koristima bez obzira na to kada ga otvorite!', 129.99, '2024-02-14', 1533);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `proizvodi`
--
ALTER TABLE `proizvodi`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `proizvodi`
--
ALTER TABLE `proizvodi`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
